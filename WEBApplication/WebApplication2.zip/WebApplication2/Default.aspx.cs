﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1;

namespace WebApplication2
{
    public partial class _Default : Page
    {

        private string HostName = "localhost";
        private string PortName = "3307";
        private string Username = "root";
        private string Password = string.Empty;

        private string UserPassword = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {

            string ConnectionString = $"datasource={HostName}; port={PortName}; username={Username}; password={Password}";
            MySqlConnection MyConn2 = new MySqlConnection(ConnectionString);
            string Quary = $"select * from felveteli_vrd.accounts";
            MyConn2.Open();
            MySqlCommand MyCommand2 = new MySqlCommand(Quary, MyConn2);
            MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
            MyAdapter.SelectCommand = MyCommand2;
            DataTable dTable = new DataTable();
            MyAdapter.Fill(dTable);
            MyConn2.Close();
            
            
            



        }
        protected void OnClick(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
            }
        }
    }
 
}